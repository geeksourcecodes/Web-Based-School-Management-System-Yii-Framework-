<?php $userName="root";
$passWord="";
$dbName="campusadmin";
$host="localhost"; ?>