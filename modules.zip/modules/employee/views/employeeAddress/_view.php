<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->employee_address_id), array('view', 'id'=>$data->employee_address_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_c_line1')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_c_line1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_c_line2')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_c_line2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_c_city')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_c_city); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_c_pincode')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_c_pincode); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_c_state')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_c_state); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_c_country')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_c_country); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_p_line1')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_p_line1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_p_line2')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_p_line2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_p_city')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_p_city); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_p_pincode')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_p_pincode); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_p_state')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_p_state); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_p_country')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_p_country); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_phone')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_phone); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('employee_address_mobile')); ?>:</b>
	<?php echo CHtml::encode($data->employee_address_mobile); ?>
	<br />

	*/ ?>

</div>