<?php
$this->breadcrumbs=array(
	'Export To PDF'
	
);?>
<p>
	<?php 
	echo "No Data Available for Export to PDF/Excel</br>";
	echo CHtml::link('GO BACK',$last_page);
	?>
	
</p>
