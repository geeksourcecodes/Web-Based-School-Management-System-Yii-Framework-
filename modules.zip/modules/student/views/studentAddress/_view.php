<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->student_address_id), array('view', 'id'=>$data->student_address_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_c_line1')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_c_line1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_c_line2')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_c_line2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_c_country')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_c_country); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_c_city')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_c_city); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_c_pin')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_c_pin); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_c_state')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_c_state); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_p_line1')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_p_line1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_p_line2')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_p_line2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_p_city')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_p_city); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_p_pin')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_p_pin); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_p_state')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_p_state); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_p_country')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_p_country); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_phone')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_phone); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_address_mobile')); ?>:</b>
	<?php echo CHtml::encode($data->student_address_mobile); ?>
	<br />

	*/ ?>

</div>