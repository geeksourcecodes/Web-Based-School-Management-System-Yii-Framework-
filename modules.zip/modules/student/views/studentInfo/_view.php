<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->student_id), array('view', 'id'=>$data->student_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_roll_no')); ?>:</b>
	<?php echo CHtml::encode($data->student_roll_no); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_merit_no')); ?>:</b>
	<?php echo CHtml::encode($data->student_merit_no); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_enroll_no')); ?>:</b>
	<?php echo CHtml::encode($data->student_enroll_no); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_college_id')); ?>:</b>
	<?php echo CHtml::encode($data->student_college_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_first_name')); ?>:</b>
	<?php echo CHtml::encode($data->student_first_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_middle_name')); ?>:</b>
	<?php echo CHtml::encode($data->student_middle_name); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('student_last_name')); ?>:</b>
	<?php echo CHtml::encode($data->student_last_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_father_name')); ?>:</b>
	<?php echo CHtml::encode($data->student_father_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_mother_name')); ?>:</b>
	<?php echo CHtml::encode($data->student_mother_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_adm_date')); ?>:</b>
	<?php echo CHtml::encode($data->student_adm_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_dob')); ?>:</b>
	<?php echo CHtml::encode($data->student_dob); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_birthplace')); ?>:</b>
	<?php echo CHtml::encode($data->student_birthplace); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_gender')); ?>:</b>
	<?php echo CHtml::encode($data->student_gender); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_name')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_name); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_relation')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_relation); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_qualification')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_qualification); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_occupation')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_occupation); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_income')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_income); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_occupation_address')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_occupation_address); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_occupation_city')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_occupation_city); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_city_pin')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_city_pin); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_home_address')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_home_address); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_phoneno')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_phoneno); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_guardian_mobile')); ?>:</b>
	<?php echo CHtml::encode($data->student_guardian_mobile); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_email_id_1')); ?>:</b>
	<?php echo CHtml::encode($data->student_email_id_1); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_email_id_2')); ?>:</b>
	<?php echo CHtml::encode($data->student_email_id_2); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_bloodgroup')); ?>:</b>
	<?php echo CHtml::encode($data->student_bloodgroup); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_tally_id')); ?>:</b>
	<?php echo CHtml::encode($data->student_tally_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_created_by')); ?>:</b>
	<?php echo CHtml::encode($data->student_created_by); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('student_creation_date')); ?>:</b>
	<?php echo CHtml::encode($data->student_creation_date); ?>
	<br />

	*/ ?>

</div>