
<h1>Edit Semester <?php //echo $model->academic_term_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
