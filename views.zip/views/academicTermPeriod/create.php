

<h1>Add Academic Year</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
