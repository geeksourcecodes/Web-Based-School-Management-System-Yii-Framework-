
<h1>Edit Academic Year<?php //echo $model->academic_terms_period_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
