

<h1>Add Country</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
