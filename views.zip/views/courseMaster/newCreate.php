<h1>Create Course</h1>

<?php echo $this->renderPartial('_newform', array('model'=>$model)); ?>
