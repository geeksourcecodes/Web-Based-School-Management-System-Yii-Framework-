<h1>Create Course</h1>

<?php echo $this->renderPartial('_newUpdateform', array('model'=>$model)); ?>
