
<h1>Update Course <?php //echo $model->course_master_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
