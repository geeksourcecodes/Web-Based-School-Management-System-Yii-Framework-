<h1>Create Course Unit</h1>

<?php echo $this->renderPartial('_newUpdateform', array('model'=>$model)); ?>
