<h1>Update Course Unit</h1>

<?php echo $this->renderPartial('updateForm', array('model'=>$model)); ?>
