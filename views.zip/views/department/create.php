
<h1>Add Department</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
