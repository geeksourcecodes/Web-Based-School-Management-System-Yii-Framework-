
<h1>Edit Department  <?php //echo $model->department_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
