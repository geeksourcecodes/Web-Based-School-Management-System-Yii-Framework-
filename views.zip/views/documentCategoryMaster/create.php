

<h1>Add Document Category</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
