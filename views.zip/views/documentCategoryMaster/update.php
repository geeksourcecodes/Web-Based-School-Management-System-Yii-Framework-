
<h1>Edit Document Category <?php //echo $model->doc_category_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
