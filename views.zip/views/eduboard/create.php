
<h1>Add Education Board</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
