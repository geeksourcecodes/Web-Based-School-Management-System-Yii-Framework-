

<h1>Edit Education Board <?php //echo $model->eduboard_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
