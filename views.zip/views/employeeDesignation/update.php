

<h1>Edit Designation  <?php //echo $model->employee_designation_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
