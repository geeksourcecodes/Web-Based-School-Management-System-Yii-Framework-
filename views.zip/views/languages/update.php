

<h1>Edit Language  <?php //echo $model->languages_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
