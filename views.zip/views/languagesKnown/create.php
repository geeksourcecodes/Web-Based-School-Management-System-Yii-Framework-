
<h1>Create LanguagesKnown</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>