
<h1>Update LanguagesKnown <?php echo $model->languages_known_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model,'info'=>$info,'address'=>$address,'photo'=>$photo,'lang'=>$lang)); ?>
