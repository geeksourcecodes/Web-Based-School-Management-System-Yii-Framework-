<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
	<meta charset="UTF-8" />
	<meta name="language" content="en" />
	<title>ECIT Installation</title>
<link href="<?php echo Yii::app()->baseUrl; ?>/css/installation.css" type="text/css" rel="stylesheet">
    </head>
   <div class="container">
   <div class="content" style="height: 565px; width: 615px;">
	<div class="header">
		<div class="app-logo">
		   <img src="<?php echo Yii::app()->baseUrl; ?>/images/product.png" alt="logo" /> 
		</div>
		<h1 class="title">Installation Process</h1>
	</div>
<?php
echo $content;
?>

</div>
</div></body>
</html> 
