
<h1>Add Message Of The Day</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
