
<div class="message-day">
<?php echo $message; ?>
</div>

