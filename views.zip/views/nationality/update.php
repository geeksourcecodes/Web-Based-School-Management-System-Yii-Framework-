
<h1>Edit Nationality  <?php //echo $model->nationality_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
