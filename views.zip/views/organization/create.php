
<h1>Add Organization</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
