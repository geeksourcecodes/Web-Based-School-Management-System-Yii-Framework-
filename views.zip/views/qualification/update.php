

<h1>Edit Qualification  <?php //echo $model->qualification_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
