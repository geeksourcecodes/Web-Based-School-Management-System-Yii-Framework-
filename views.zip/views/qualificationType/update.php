
<h1>Update Course Category <?php //echo $model->qualification_type_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>

