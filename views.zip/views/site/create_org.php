
<h1 style="color: #555; font-weight: normal; font-size: 17px;"> Create an Institute / College </h1>
<?php echo $this->renderPartial('org_form', array('model'=>$model)); ?>
