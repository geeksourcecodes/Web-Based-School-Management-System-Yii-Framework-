

<?php echo $this->renderPartial('user_form', array('model'=>$model)); ?>
