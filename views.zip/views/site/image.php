<?php
header('Content-Type: ' . $model->file_type);
print $model->logo; 
exit(); 
?>
