<h1> Welcome to ECIT </h1>

<p> There is no such organization created yet please create atleast one organization in this application </p>

<?php echo CHtml::link('Create Organization',Yii::app()->createUrl('site/createOrg'));?> 
