

<h1>Edit State  <?php //echo $model->state_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
