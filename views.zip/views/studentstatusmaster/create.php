
<h1>Add Student Status</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
