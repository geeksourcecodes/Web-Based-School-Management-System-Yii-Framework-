

<h1>Update UnitDetailTable <?php echo $model->unit_detail_id; ?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
