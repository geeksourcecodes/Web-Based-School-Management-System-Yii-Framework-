
<h1>Edit User <?php //echo $model->user_organization_email_id; ?></h1>

<?php echo $this->renderPartial('_changeform', array('model'=>$model)); ?>
