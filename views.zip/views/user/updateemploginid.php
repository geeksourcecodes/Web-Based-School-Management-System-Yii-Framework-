
<h1>Edit Employee Loginid  <?php //echo $model->user_id; ?></h1>

<?php echo $this->renderPartial('_formemploginid', array('model'=>$model)); ?>
