

<h1>Edit Student Loginid  <?php //echo $model->user_id; ?></h1>

<?php echo $this->renderPartial('_formloginid', array('model'=>$model)); ?>
